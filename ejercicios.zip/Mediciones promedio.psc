Algoritmo PromedioMediciones
    Definir n, i Como Entero
    Definir presion, suma, promedio, maximo, minimo Como Real
    
    Escribir "Ingrese la cantidad de mediciones (N):"
    Leer n
    suma <- 0
    
    Para i <- 1 Hasta n Con Paso 1 Hacer
        Escribir "Ingrese la medici�n ", i, ":"
        Leer presion
        suma <- suma + presion
        
        // Inicializaci�n correcta de mayor y menor
        Si i = 1 Entonces
            maximo <- presion
            minimo <- presion
        Sino
            Si presion > maximo Entonces
                maximo <- presion
            FinSi
            Si presion < minimo Entonces
                minimo <- presion
            FinSi
        FinSi
    FinPara
    
    promedio <- suma / n
    Escribir "Promedio: ", promedio
    Escribir "Mayor valor: ", maximo
    Escribir "Menor valor: ", minimo
FinAlgoritmo