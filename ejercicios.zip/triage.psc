Algoritmo SistemaTriage
    Definir sistolica, saturacion Como Real
    
    Escribir "Ingrese la saturaci�n de ox�geno:"
    Leer saturacion
    Escribir "Ingrese la presi�n sist�lica:"
    Leer sistolica
    
    Si saturacion < 90 Entonces
        Escribir "Emergencia"
    Sino
        Si sistolica < 90 Entonces
            Escribir "Urgente"
        Sino
            Escribir "Estable"
        FinSi
    FinSi
FinAlgoritmo